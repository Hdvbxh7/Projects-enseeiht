% Fonction encodage_image (exercice_2.m)

function [I_encodee,dictionnaire,hauteur_I,largeur_I] = encodage_image(I)



end