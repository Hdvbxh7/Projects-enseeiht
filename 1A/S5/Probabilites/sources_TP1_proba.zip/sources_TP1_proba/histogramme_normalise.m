% Fonction histogramme_normalise (exercice_2.m)

function [vecteur_Imin_a_Imax,vecteurs_frequences] = histogramme_normalise(I)

    

end