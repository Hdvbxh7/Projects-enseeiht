% Fonction tirages_aleatoires (exercice_1.m)

function tirages_angles = tirages_aleatoires_uniformes(n_tirages)
    
 

end